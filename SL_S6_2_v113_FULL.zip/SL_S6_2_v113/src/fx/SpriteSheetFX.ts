import { Assets, type Spritesheet } from 'pixi.js';

let sheetPromise: Promise<Spritesheet> | null = null;
let cached: Spritesheet | null = null;

export function isFxSheetReady(): boolean {
  return cached != null;
}

/** Load the public spritesheet once (idempotent). */
export async function loadFxSheet(): Promise<Spritesheet> {
  if (cached) return cached;
  if (!sheetPromise) {
    sheetPromise = (async () => {
      const res = (await Assets.load('/fx/fx_sheet.json')) as unknown as Spritesheet;
      cached = res;
      return res;
    })();
  }
  return sheetPromise;
}

/** Best-effort preload (fire-and-forget). */
export function preloadFxSheet(): void {
  void loadFxSheet().catch(() => {
    // Silent: fallback to particle FX if load fails.
  });
}
