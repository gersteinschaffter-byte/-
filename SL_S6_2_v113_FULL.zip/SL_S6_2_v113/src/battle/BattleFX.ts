import { Container, Graphics, BLEND_MODES, AnimatedSprite } from 'pixi.js';
import ParticleSystem, { type EmitterConfig } from '../fx/ParticleSystem';
import { Tween, TweenRunner, easeOutCubic } from '../fx/Tween';
import { spawnFloatingText } from '../fx/FloatingText';
import { spawnFlashLine } from '../fx/FlashLine';
import { preloadFxSheet, loadFxSheet, isFxSheetReady } from '../fx/SpriteSheetFX';

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 战斗粒子预设
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/** 火球命中 — 橙红爆散 */
export const FireHitPreset: EmitterConfig = {
  rate: 0,
  life: [12, 28],
  speedX: [-4, 4],
  speedY: [-5, 2],
  accelY: 0.12,
  size: [2, 4.5],
  sizeEnd: [0.3, 0.8],
  alpha: [0.7, 1.0],
  alphaEnd: 0,
  colors: [0xff6633, 0xff9944, 0xffcc22, 0xffe088],
  emitZone: 'point',
  spread: 18,
  blendMode: BLEND_MODES.ADD,
  drawGlow: true,
};


/** 雷电命中 — 蓝紫电弧爆闪 */
export const ThunderStrikePreset: EmitterConfig = {
  rate: 0,
  life: [8, 20],
  speedX: [-5, 5],
  speedY: [-5, 4],
  accelY: 0.1,
  size: [1.2, 3.8],
  sizeEnd: [0.2, 0.6],
  alpha: [0.7, 1.0],
  alphaEnd: 0,
  colors: [0x66ccff, 0x88aaff, 0xb399ff, 0xffffff],
  emitZone: 'point',
  spread: 20,
  blendMode: BLEND_MODES.ADD,
  drawGlow: true,
};

/** 圣光命中 — 金白碎光 */
export const HolyBurstPreset: EmitterConfig = {
  rate: 0,
  life: [10, 24],
  speedX: [-4, 4],
  speedY: [-4, 3],
  accelY: 0.05,
  size: [1.5, 4],
  sizeEnd: [0.2, 0.7],
  alpha: [0.65, 1.0],
  alphaEnd: 0,
  colors: [0xffe07a, 0xfff0b0, 0xffffff, 0xffcc66],
  emitZone: 'point',
  spread: 24,
  blendMode: BLEND_MODES.ADD,
  drawGlow: true,
};

/** 冰霜命中 — 冷蓝碎晶 */
export const FrostShatterPreset: EmitterConfig = {
  rate: 0,
  life: [12, 26],
  speedX: [-3.5, 3.5],
  speedY: [-3.5, 2.5],
  accelY: 0.05,
  size: [1.2, 3.2],
  sizeEnd: [0.2, 0.6],
  alpha: [0.55, 0.95],
  alphaEnd: 0,
  colors: [0xa9e7ff, 0x88d8ff, 0xdcf6ff, 0x66bbff],
  emitZone: 'point',
  spread: 28,
  blendMode: BLEND_MODES.ADD,
  drawGlow: true,
};

/** 治疗 — 绿色上升光点 */
export const HealRisePreset: EmitterConfig = {
  rate: 0,
  life: [18, 36],
  speedX: [-1.2, 1.2],
  speedY: [-3.5, -1.5],
  accelY: -0.02,
  size: [1.5, 3.5],
  sizeEnd: [0.3, 0.6],
  alpha: [0.5, 0.9],
  alphaEnd: 0,
  colors: [0x54ff8d, 0x88ffbb, 0xaaffcc, 0xffffff],
  emitZone: 'point',
  spread: 30,
  blendMode: BLEND_MODES.ADD,
  drawGlow: true,
};

/** 横扫 / AOE — 宽幅散射 */
export const SweepImpactPreset: EmitterConfig = {
  rate: 0,
  life: [10, 22],
  speedX: [-6, 6],
  speedY: [-3, 3],
  accelY: 0.06,
  size: [1.5, 3.5],
  sizeEnd: [0.2, 0.5],
  alpha: [0.6, 1.0],
  alphaEnd: 0,
  colors: [0xffaa22, 0xffdd55, 0xffffff, 0xff8800],
  emitZone: 'point',
  spread: 40,
  blendMode: BLEND_MODES.ADD,
  drawGlow: false,
};

/** 中毒 — 紫色下坠 */
export const PoisonDripPreset: EmitterConfig = {
  rate: 0,
  life: [16, 30],
  speedX: [-1, 1],
  speedY: [0.8, 2.5],
  accelY: 0.04,
  size: [1.2, 2.8],
  sizeEnd: [0.3, 0.5],
  alpha: [0.5, 0.8],
  alphaEnd: 0,
  colors: [0xcc44ff, 0xaa22dd, 0xee88ff, 0x8833cc],
  emitZone: 'point',
  spread: 20,
  blendMode: BLEND_MODES.ADD,
  drawGlow: false,
};

/** 护盾 — 蓝色微光环绕 */
export const ShieldGlintPreset: EmitterConfig = {
  rate: 0,
  life: [14, 26],
  speedX: [-2, 2],
  speedY: [-2, 2],
  size: [1.2, 2.5],
  sizeEnd: [0.2, 0.5],
  alpha: [0.4, 0.8],
  alphaEnd: 0,
  colors: [0x66ccff, 0x88ddff, 0xaaeeff, 0xffffff],
  emitZone: 'point',
  spread: 35,
  blendMode: BLEND_MODES.ADD,
  drawGlow: true,
};

/** 阵亡 — 灰白碎片爆散 */
export const DeathShatterPreset: EmitterConfig = {
  rate: 0,
  life: [18, 40],
  speedX: [-5, 5],
  speedY: [-6, 2],
  accelY: 0.10,
  size: [2, 5],
  sizeEnd: [0.5, 1],
  alpha: [0.6, 1.0],
  alphaEnd: 0,
  colors: [0xaaaaaa, 0xcccccc, 0x888888, 0xffffff],
  emitZone: 'point',
  spread: 22,
  blendMode: BLEND_MODES.ADD,
  drawGlow: false,
  rotSpeed: [-0.06, 0.06],
};

/** 通用命中 — 白色微粒 */
export const HitSparkPreset: EmitterConfig = {
  rate: 0,
  life: [8, 18],
  speedX: [-3, 3],
  speedY: [-3, 3],
  size: [1, 3],
  sizeEnd: [0.2, 0.5],
  alpha: [0.5, 0.9],
  alphaEnd: 0,
  colors: [0xffffff, 0xddeeff, 0xbbccff],
  emitZone: 'point',
  spread: 12,
  blendMode: BLEND_MODES.ADD,
  drawGlow: false,
};

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 技能→粒子预设映射
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

const SKILL_HIT_FX: Record<string, { preset: EmitterConfig; count: number }> = {
  sk_fireball:  { preset: FireHitPreset,       count: 14 },
  sk_sweep:     { preset: SweepImpactPreset,   count: 10 },
  sk_heal:      { preset: HealRisePreset,      count: 10 },
  sk_aura_heal: { preset: HealRisePreset,      count: 8  },
  sk_shield:    { preset: ShieldGlintPreset,   count: 10 },
  sk_poison:    { preset: PoisonDripPreset,    count: 8  },
  sk_slow:      { preset: FrostShatterPreset,  count: 8  },
  sk_warcry:    { preset: FireHitPreset,       count: 8  },

  sk_thunderbolt: { preset: ThunderStrikePreset, count: 16 },
  sk_blizzard:    { preset: FrostShatterPreset,  count: 14 },
  sk_berserk:     { preset: FireHitPreset,       count: 8  },
  sk_weaken:      { preset: PoisonDripPreset,    count: 8  },
  sk_ironwall:    { preset: ShieldGlintPreset,   count: 10 },
  sk_haste:       { preset: HealRisePreset,      count: 8  },
  sk_cleave:      { preset: SweepImpactPreset,   count: 12 },
  sk_smite:       { preset: HolyBurstPreset,     count: 18 },
  sk_revitalize:  { preset: HealRisePreset,      count: 10 },
  sk_curse:       { preset: PoisonDripPreset,    count: 8  },
  sk_mass_heal:   { preset: HealRisePreset,      count: 14 },
  sk_empower:     { preset: HolyBurstPreset,     count: 8  },

  sk_raging_inferno: { preset: FireHitPreset,       count: 16 },
  sk_ember_guard:    { preset: ShieldGlintPreset,   count: 8  },
  sk_tidal_blessing: { preset: HealRisePreset,      count: 12 },
  sk_frost_barrier:  { preset: FrostShatterPreset,  count: 12 },
  sk_gale_combo:     { preset: SweepImpactPreset,   count: 12 },
  sk_haste_banner:   { preset: HealRisePreset,      count: 8  },
  sk_solar_judgment: { preset: HolyBurstPreset,     count: 18 },
  sk_holy_aegis:     { preset: ShieldGlintPreset,   count: 12 },
  sk_nether_burst:   { preset: ThunderStrikePreset, count: 12 },
  sk_curse_mist:     { preset: PoisonDripPreset,    count: 10 },
};

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// BattleFXManager — 集中管理所有战斗特效
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

export class BattleFXManager {
  private readonly fxLayer: Container;
  private readonly runner: TweenRunner;
  private readonly particles: ParticleSystem;
  private readonly arenaW: number;
  private readonly arenaH: number;

  /** 技能颜色缓存：actorId → { color, ttl } */
  private readonly skillColorCache = new Map<string, { color: number; ttl: number }>();
  /** 最近施法缓存：actorId → { skillId, ttl } */
  private readonly recentSkillCache = new Map<string, { skillId: string; ttl: number }>();

  private spriteSheet: any | null = null;
  private spriteSheetLoading = false;

  constructor(fxLayer: Container, runner: TweenRunner, arenaW: number, arenaH: number) {
    this.fxLayer = fxLayer;
    this.runner = runner;
    this.arenaW = arenaW;
    this.arenaH = arenaH;

    this.particles = new ParticleSystem({ maxParticles: 120 });
    this.fxLayer.addChild(this.particles);

    // Preload optional sprite-sheet FX (non-blocking).
    preloadFxSheet();
  }

  /** 每帧调用 */
  update(dt: number): void {
    this.particles.onUpdate(dt);
    for (const [id, v] of this.skillColorCache.entries()) {
      v.ttl -= dt;
      if (v.ttl <= 0) this.skillColorCache.delete(id);
    }
    for (const [id, v] of this.recentSkillCache.entries()) {
      v.ttl -= dt;
      if (v.ttl <= 0) this.recentSkillCache.delete(id);
    }
  }

  /** 清空所有特效 */
  clear(): void {
    this.particles.clearAll();
    this.skillColorCache.clear();
    this.recentSkillCache.clear();
  }

  // ── 攻击线 ──

  attackLine(x0: number, y0: number, x1: number, y1: number, color = 0xffffff): void {
    spawnFlashLine(this.fxLayer, x0, y0, x1, y1, this.runner, { color });
  }

  // ── 浮动文字 ──

  floatingText(text: string, x: number, y: number, opts?: Parameters<typeof spawnFloatingText>[5]): void {
    spawnFloatingText(this.fxLayer, text, x, y, this.runner, opts);
  }

  // ── 技能颜色跟踪 ──

  setSkillColor(actorId: string, color: number): void {
    this.skillColorCache.set(actorId, { color, ttl: 40 });
  }

  setRecentSkill(actorId: string, skillId: string): void {
    this.recentSkillCache.set(actorId, { skillId, ttl: 26 });
  }

  getSkillColor(actorId: string): number | null {
    const c = this.skillColorCache.get(actorId);
    return c ? c.color : null;
  }

  getRecentSkill(actorId: string): string | null {
    const c = this.recentSkillCache.get(actorId);
    return c ? c.skillId : null;
  }

  // ── 技能命中粒子 ──

  /** 根据技能ID在目标位置爆发对应粒子 */
  skillHitParticles(skillId: string, x: number, y: number): void {
    const fx = SKILL_HIT_FX[skillId];
    if (fx) {
      this.particles.burst(fx.preset, x, y, fx.count);
    }
  }

  /** 通用命中火花（无技能时使用） */
  hitSpark(x: number, y: number, count = 6): void {
    this.particles.burst(HitSparkPreset, x, y, count);
    this.playSprite('hit_spark', x, y, { scale: 1.0, speed: 0.7, blendAdd: true });
  }

  // ── 治疗粒子 ──

  healParticles(x: number, y: number): void {
    this.particles.burst(HealRisePreset, x, y, 10);
    this.playSprite('heal_ring', x, y, { scale: 1.2, speed: 0.55, blendAdd: true });
  }
// ── 护盾粒子/特效 ──

shieldParticles(x: number, y: number): void {
  this.particles.burst(ShieldGlintPreset, x, y, 10);
  this.playSprite('shield_pop', x, y, { scale: 1.25, speed: 0.55, blendAdd: true, alpha: 0.95 });
}


  // ── 阵亡爆散 ──

  deathParticles(x: number, y: number): void {
    this.particles.burst(DeathShatterPreset, x, y, 18);
  }

  // ── 全屏闪光 ──

  screenFlash(color: number, alpha = 0.18, lifeFrames = 16): void {
    const flash = new Graphics();
    flash.beginFill(color, alpha);
    flash.drawRect(0, 0, this.arenaW, this.arenaH);
    flash.endFill();
    flash.alpha = 0;
    this.fxLayer.addChild(flash);

    const fadeIn = Math.max(2, (lifeFrames * 0.25) | 0);
    const fadeOut = Math.max(4, (lifeFrames * 0.75) | 0);
    this.runner.add(
      Tween.to(flash, { alpha: 1 }, fadeIn, easeOutCubic, () => {
        this.runner.add(
          Tween.to(flash, { alpha: 0 }, fadeOut, easeOutCubic, () => flash.destroy()),
        );
      }),
    );
  }

  // ── 扩散圆环 ──

  expandRing(x: number, y: number, color: number, radius = 60): void {
    const ring = new Graphics();
    ring.lineStyle(3, color, 0.7);
    ring.drawCircle(0, 0, 10);
    ring.position.set(x, y);
    ring.alpha = 0.9;
    this.fxLayer.addChild(ring);

    const scale = radius / 10;
    this.runner.add(Tween.to(ring, { alpha: 0 }, 20, easeOutCubic, () => ring.destroy()));
    this.runner.add(Tween.to(ring.scale, { x: scale, y: scale }, 20, easeOutCubic));
  }
  private ensureSpriteSheetLoaded(): void {
    if (this.spriteSheet || this.spriteSheetLoading) return;
    this.spriteSheetLoading = true;
    void loadFxSheet()
      .then((s) => {
        this.spriteSheet = s;
      })
      .catch(() => {
        /* fallback */
      })
      .finally(() => {
        this.spriteSheetLoading = false;
      });
  }

  private playSprite(
    key: 'slash_arc' | 'hit_spark' | 'shield_pop' | 'heal_ring',
    x: number,
    y: number,
    opts?: { scale?: number; speed?: number; alpha?: number; blendAdd?: boolean },
  ): void {
  // If sheet isn't ready yet, start loading and fallback to particles for this call.
  if (!isFxSheetReady() && !this.spriteSheet) {
    this.ensureSpriteSheetLoaded();
    return;
  }
  const sheet = (this.spriteSheet ?? null) as any;
  const frames = sheet?.animations?.[key];
  if (!frames || frames.length === 0) return;

  const anim = new AnimatedSprite(frames);
  anim.anchor.set(0.5);
  anim.position.set(x, y);
  anim.loop = false;
  anim.animationSpeed = opts?.speed ?? 0.6;
  anim.alpha = opts?.alpha ?? 1;
  anim.scale.set(opts?.scale ?? 1);
  if (opts?.blendAdd) anim.blendMode = BLEND_MODES.ADD;
  anim.onComplete = () => anim.destroy();
  anim.play();
  this.fxLayer.addChild(anim);
  }
}

