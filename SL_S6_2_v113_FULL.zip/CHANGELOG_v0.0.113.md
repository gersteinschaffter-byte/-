# v0.0.113

- 集成 4 套 SpriteSheet 攻击/治疗/护盾特效（public/fx/fx_sheet.*）
- BattleFXManager 支持可选的 sprite-sheet 动画播放（命中/治疗/护盾）
- 修复：护盾获得时误用治疗粒子（改为护盾特效）

