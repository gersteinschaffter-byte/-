# FX Pack (4 sets, 10 frames each)

- Format: `public/fx/fx_sheet.png` + `public/fx/fx_sheet.json` (Pixi Spritesheet)
- Anim keys:
  - `slash_arc`
  - `hit_spark`
  - `shield_pop`
  - `heal_ring`

Pixi usage:
```ts
import { Assets, AnimatedSprite } from "pixi.js";

const sheet = await Assets.load("/fx/fx_sheet.json");
const anim = new AnimatedSprite(sheet.animations["slash_arc"]);
anim.animationSpeed = 0.5;
anim.loop = false;
anim.onComplete = () => anim.destroy();
anim.play();
```
